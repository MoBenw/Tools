<?php
return array (
  'fields' => 
  array (
    0 => 'id',
    1 => 'tel',
    2 => 'passwd',
    3 => 'role',
  ),
  'primaryKey' => 
  array (
    0 => 'id',
  ),
);
