<?php
return array (
  'fields' => 
  array (
    0 => 'id',
    1 => 'name',
    2 => 'type',
    3 => 'time',
    4 => 'place',
    5 => 'tel',
    6 => 'status',
    7 => 'desc',
  ),
  'primaryKey' => 
  array (
    0 => 'id',
  ),
);
