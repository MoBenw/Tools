<?php if (!class_exists("Template_56f4f8d58f6fb57f468265af7f8d0bef", false)) { class Template_56f4f8d58f6fb57f468265af7f8d0bef extends suda\template\compiler\suda\Template { protected $name="suda/lostandfound:1.0.0:write";protected $module="suda/lostandfound:1.0.0"; protected $source="D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/write.tpl.html";protected function _render_template() {  ?><!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link href="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.css" rel="stylesheet">

	<!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
	<script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/jquery.min.js"></script>

	<!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
	<script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.js"></script>
	<title>填写表单</title>
</head>

<body>
	<div class="container">
		<div class="row clearfix">
			<div class="col-md-12 column">
				<div class=" page-header dropdown col-md-12">
					<h1>
						失物招领系统 <small>v2.0</small>
					</h1>
					<button type="button" class=" pull-right btn dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
						用户中心
						<span class="caret"></span>
					</button>
					<ul class="dropdown-menu pull-right" role="menu" aria-labelledby="dropdownMenu1">
						<li role="presentation">
							<a role="menuitem" tabindex="-1" href="<?php echo $this->url('signup'); ?>">注册</a>
						</li>
						<li role="presentation">
							<a role="menuitem" tabindex="-1" href="<?php echo $this->url('signin'); ?>">登入</a>
						</li>
						<li role="presentation">
							<a role="menuitem" tabindex="-1" href="<?php echo $this->url('user'); ?>">个人中心</a>
						</li>
					</ul>
				</div>
				<div class="row clearfix">
					<div class="col-md-3 column">
						<ul class="nav nav-stacked nav-pills">
							<li>
								<a href="<?php echo $this->url('index'); ?>">首页</a>
							</li>
							<li class="active">
								<a href="<?php echo $this->url('write'); ?>">我要填写</a>
							</li>
							<li>
								<a href="<?php echo $this->url('setting'); ?>">我是管理员</a>
							</li>
						</ul>
					</div>
					<div class="col-md-9 column">

						<form class="form-horizontal" role="form" action="" method="post">
							<div class="form-group">
								<label for="input1" class="col-sm-2 control-label">物品名</label>
								<div class="col-sm-3">
									<input type="text" class="form-control" id="input1" name="name" />
								</div>
							</div>

							<div class="form-group">
								<label class="col-sm-2 control-label">发生了什么</label>
								<div class="radio  col-sm-10 ">

									<label for="radio1" class="control-label">
										<input type="radio" name="type" value="lost" id="radio1">我丢了东西
									</label>
									<label for="radio2" class="control-label">
										<input type="radio" name="type" value="found" id="radio2">我拾了东西
									</label>
								</div>
							</div>


							<div class="form-group">
								<label for="input2" class="col-sm-2 control-label">时间</label>
								<div class="col-sm-3">
									<input type="text" class="form-control" id="input2" name="time" />
								</div>
							</div>
							<div class="form-group">
								<label for="input3" class="col-sm-2 control-label">地点</label>
								<div class="col-sm-3">
									<input type="text" class="form-control" id="input3" name="place" />
								</div>
							</div>
							<div class="form-group">
								<label for="input4" class="col-sm-2 control-label">电话</label>
								<div class="col-sm-3">
									<input type="text" class="form-control" id="input4" name="tel" />
								</div>
							</div>


							<div class="form-group">
								<label for="input5" class="col-sm-2 control-label">详细描述</label>
								<div class="col-sm-10">
									<textarea class="form-control" id="input5" rows="3" name="desc" style="overflow:hidden"></textarea>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
									<button type="submit" class=" btn btn-success">Do it</button>
								</div>
							</div>
						</form>

					</div>
				</div>
			</div>
		</div>
	</div>
</body>

</html><?php }} } return ["class"=>"Template_56f4f8d58f6fb57f468265af7f8d0bef","name"=>"suda/lostandfound:1.0.0:write","source"=>"D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/write.tpl.html","module"=>"suda/lostandfound:1.0.0"]; 