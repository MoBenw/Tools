<?php if (!class_exists("Template_abe63d0f28f292b44c638035f51585e7", false)) { class Template_abe63d0f28f292b44c638035f51585e7 extends suda\template\compiler\suda\Template { protected $name="suda/lostandfound:1.0.0:setting";protected $module="suda/lostandfound:1.0.0"; protected $source="D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/setting.tpl.html";protected function _render_template() {  ?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link href="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.css" rel="stylesheet" />

    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/jquery.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.js"></script>
    <title>后台</title>
</head>

<body>
    <div class="container">
        <div class="row clearfix">
            <div class="col-md-12 column">
                <div class=" page-header dropdown col-md-12">
                    <h1>失物招领系统 <small>v2.0</small></h1>
                    <button type="button" class=" pull-right btn dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
                        用户中心 <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu pull-right" role="menu" aria-labelledby="dropdownMenu1">
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('signup'); ?>">注册</a>
                        </li>
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('signin'); ?>">登入</a>
                        </li>
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('user'); ?>">个人中心</a>
                        </li>
                    </ul>
                </div>
                <div class="row clearfix">
                    <div class="col-md-3 column">
                        <ul class="nav nav-stacked nav-pills">
                            <li class="active"><a href="#">用户列表</a></li>
                            <li><a href="<?php echo $this->url('index'); ?>">返回主页</a></li>
                        </ul>
                    </div>
                    <div class="col-md-9 column">
                        <div class="row clearfix">
                            <div class="col-md-12 column">
                                <h1>用户信息</h1>

                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>编号</th>
                                            <th>Tel</th>
                                            <th>密码</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                        <?php foreach($this->get("fields")as $key => $value): ?>
                                        <tr>
                                            <?php foreach($value as $key2 => $value2): ?>
                                            <?php if ($key2 != "role"): ?>
                                            <td><?php echo htmlspecialchars(__($value2), ENT_SUBSTITUTE | ENT_QUOTES | ENT_HTML5); ?></td>
                                            <?php endif; ?>
                                            <?php endforeach; ?>
                                        </tr>
                                        <?php endforeach; ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php }} } return ["class"=>"Template_abe63d0f28f292b44c638035f51585e7","name"=>"suda/lostandfound:1.0.0:setting","source"=>"D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/setting.tpl.html","module"=>"suda/lostandfound:1.0.0"]; 