<?php if (!class_exists("Template_bc61efe52639bade53c3b5011d70230e", false)) { class Template_bc61efe52639bade53c3b5011d70230e extends suda\template\compiler\suda\Template { protected $name="suda/lostandfound:1.0.0:index";protected $module="suda/lostandfound:1.0.0"; protected $source="D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/index.tpl.html";protected function _render_template() {  ?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/jquery.min.js"></script>

    <!-- 最新的 Bootstrap 核心 JavaScript 文件 -->
    <script src="<?php echo suda\template\Manager::assetServer(suda\template\Manager::getStaticAssetPath($this->getModule())); ?>/bootstrap/bootstrap.min.js"></script>
    <title>首页</title>
</head>

<body>
    <div class="container">
        <div class="row clearfix">
            <div class="col-md-12 column">
                <div class=" page-header dropdown col-md-12">
                    <h1>
                        失物招领系统 <small>v2.0</small>
                    </h1>
                    <button type="button" class=" pull-right btn dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown">
                        用户中心
                        <span class="caret"></span>
                    </button>
                    <ul class="dropdown-menu pull-right" role="menu" aria-labelledby="dropdownMenu1">
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('signup'); ?>">注册</a>
                        </li>
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('signin'); ?>">登入</a>
                        </li>
                        <li role="presentation">
                            <a role="menuitem" tabindex="-1" href="<?php echo $this->url('user'); ?>">个人中心</a>
                        </li>
                    </ul>
                </div>
                <div class="row clearfix">
                    <div class="col-md-3 column">
                        <ul class="nav nav-stacked nav-pills">
                            <li class="active">
                                <a href="#">首页</a>
                            </li>
                            <li>
                                <a href="<?php echo $this->url('write'); ?>">我要填写</a>
                            </li>
                            <li>
                                <a href="<?php echo $this->url('setting'); ?>">我是管理员</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-9 column">

                        <h1>物品列表</h1>

                       
                            <?php foreach($this->get("fields")as $key => $value): ?>
                            <a href="<?php echo $this->url('show',$key); ?>"><h3>
                                <?php foreach($value as $key2 => $value2): ?>
                                    <?php if ($key2 == 'time'): ?>
                                    <?php echo htmlspecialchars(__($value2), ENT_SUBSTITUTE | ENT_QUOTES | ENT_HTML5); ?>
                                    <?php endif; ?>

                                    <?php if ($key2 == 'place'): ?>
                                    <?php echo htmlspecialchars(__($value2), ENT_SUBSTITUTE | ENT_QUOTES | ENT_HTML5); ?>
                                    <?php endif; ?>

                                    <?php if ($key2 == 'type'): ?>
                                    <?php echo htmlspecialchars(__($value2), ENT_SUBSTITUTE | ENT_QUOTES | ENT_HTML5); ?>
                                    <?php endif; ?>

                                    <?php if ($key2 == 'name'): ?>
                                    <?php echo htmlspecialchars(__($value2), ENT_SUBSTITUTE | ENT_QUOTES | ENT_HTML5); ?>
                                    <?php endif; ?>


                                <?php endforeach; ?>
                            </h3></a>
                            <?php endforeach; ?>

                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html><?php }} } return ["class"=>"Template_bc61efe52639bade53c3b5011d70230e","name"=>"suda/lostandfound:1.0.0:index","source"=>"D:\\GitHub\\Lost-And-Found\\Demo\\app\\modules\\welcome\\resource\\template\\default/index.tpl.html","module"=>"suda/lostandfound:1.0.0"]; 