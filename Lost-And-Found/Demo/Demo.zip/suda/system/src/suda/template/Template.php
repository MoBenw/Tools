<?php

namespace suda\template;


interface Template
{
    public function render();
    public function echo();
}
